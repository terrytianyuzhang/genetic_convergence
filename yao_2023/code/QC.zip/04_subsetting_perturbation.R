library(glue)
work_directory <- '/Users/tianyuzhang/Documents/convergence_risk_gene/try_Cleary_data/'    
residual_matrix <- readRDS(file = glue(work_directory, 'data/intermediate_data/residual_matrix.rds'))

perturbation_interest <- c('non-targeting', 'STAT1', 'STAT2', 'MEF2C', 'KIDINS220', 'ADO', 'IRAK1', 'IRAK4', 'MAPK1')
residual_subset <- residual_matrix[residual_matrix$Guides_collapsed_by_gene %in% perturbation_interest, ]
table(residual_subset$Guides_collapsed_by_gene)

saveRDS(residual_subset, glue(work_directory, 'data/intermediate_data/residual_matrix_small.rds'))
